﻿var bodyWidth = $("body").css("width");
$("div.items").css("width",(bodyWidth.substring(0,bodyWidth.length-2)-380)+"px");

//参与抽奖人数初始值
var itemCount= 120;
//跑马灯循环
var tx;
var runtx;
//是否正在运行跑马灯
var isRun=true;
//是否跑马灯暂停状态
var pause =false;
//排名分组显示算法已经取消
//var ts=20
//默认跑马灯频率
var pl=50;
//程序是否开始运行用于判断程序是否开始运行
var isStart=false;
	
var zzs = "#98ff98";
//跑马灯音效
var runingmic=document.getElementById("runingmic");
runingmic.volume=0.5;
//中奖音效
var pausemic=document.getElementById("pausemic");
pausemic.volume=1.0;

var keyStatus=false;



var wb;//读取完成的数据
var rABS = false; //是否将文件读取为二进制字符串

var f;

var reader;

var data;

var v = 6;




$("#inputsh").mouseover(function(){
  $("#inputsh").css("opacity","1");
});

$("#inputsh").mouseout(function(){
  $("#inputsh").css("opacity","0.1");
});



/*
* 导入*/
/*
    FileReader共有4种读取方法：
    1.readAsArrayBuffer(file)：将文件读取为ArrayBuffer。
    2.readAsBinaryString(file)：将文件读取为二进制字符串
    3.readAsDataURL(file)：将文件读取为Data URL
    4.readAsText(file, [encoding])：将文件读取为文本，encoding缺省值为'UTF-8'
                 */

function importf(obj) {//导入
    if(!obj.files) {
        return;
    }
    f = obj.files[0];
    reader = new FileReader();
    reader.onload = function(e) {
        data = e.target.result;
        if(rABS) {
            wb = XLSX.read(btoa(fixdata(data)), {//手动转化
                type: 'base64'
            });
        } else {
            wb = XLSX.read(data, {
                type: 'binary'
            });
        }
        //wb.SheetNames[0]是获取Sheets中第一个Sheet的名字
        //wb.Sheets[Sheet名]获取第一个Sheet的数据
        //document.getElementById("demo").innerHTML= JSON.stringify( XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]));
        data = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);

        init();
        for(var i = 0;i<data.length;i++){
            for(var item in data[i]){
                console.log(item+":"+data[i][item]);
            }
        }
    };
    if(rABS) {
        reader.readAsArrayBuffer(f);
    } else {
        reader.readAsBinaryString(f);
    }
}

function fixdata(data) { //文件流转BinaryString
    var o = "",
        l = 0,
        w = 10240;
    for(; l < data.byteLength / w; ++l) o += String.fromCharCode.apply(null, new Uint8Array(data.slice(l * w, l * w + w)));
    o += String.fromCharCode.apply(null, new Uint8Array(data.slice(l * w)));
    return o;
}


function init(){
    v=6;
    //初始化皮肤
    if(localStorage.getItem("pf")){
		var	pf = localStorage.getItem("pf");
		dynamicLoading.css("./css/style"+pf+".css");
		$("#bodybg img").attr("src","./images/bodybg"+pf+".jpg");
		$("input[name=pf][value="+pf+"]").attr("checked",true);
		if(pf!=1){
		    zzs="#ba3030";
		}
	}

    //初始化标题
    if(localStorage.getItem("title")){
		$("#title").val(localStorage.getItem("title"));
	}
    $(".top").text($("#title").val());
    
    //频率模式本地存储  	 
	if(localStorage.getItem("ms")){
		pl = localStorage.getItem("ms");
		$("input[name=ms][value="+pl+"]").attr("checked",true);
	}
	//排名信息本地存储
	if(localStorage.getItem("sequence")){
        var ssHtml = localStorage.getItem("sequence");
		$(".ss").html(ssHtml);
	}
	
	//已经取消的输入
	//var inputItemCount = prompt("请输入参与抽奖人数(请输入数字，输入非数字会按默认人数计算)。");
	
	//本地排名信息存储
	if(localStorage.getItem("itemCount")){
		itemCount=localStorage.getItem("itemCount");
	}
    //本地设定回显  	 
	$("#personCount").val(itemCount);
	
	//创建item小方格
	for(var i=0;i<data.length;i++){

		var a=data[i]

        $("div.items").append("<div class='item i"+i+"'><div class='xingming'>"+a["姓名"]+"</div><div class='xuehao' style='display: none'>"+a["学号"]+"</div></div>");


        /*for(var item in data[i]){
            console.log(item+":"+data[i][item]);

        }*/

    }
    /*
    * for(var i = 0;i<data.length;i++){
            for(var item in data[i]){
                console.log(item+":"+data[i][item]);
            }
        }*/
	//本地存储item宽度信息
	if(localStorage.getItem("itemk")){
		$("div.item").css("width",localStorage.getItem("itemk")+"px");
	}
    //本地存储item高度信息
	if(localStorage.getItem("itemg")){
		$("div.item").css("height",localStorage.getItem("itemg")+"px");
		$("div.item").css("line-height",localStorage.getItem("itemg")+"px");
	}
    //回显设定item宽高
	$("#itemk").attr("placeholder",$(".i1").css("width"));
	$("#itemg").attr("placeholder",$(".i1").css("height"));
	
	//初始化排序信息
	$(".ss li").each(function(idx,item){
		$(".i"+$(item).attr("data-number")).addClass("ignore");
	});
	
	//$("div.menu").css("height",$("div.items").css("height"));
    $("body").keyup(function(e){
    	keyStatus=false;
	});
	//全局键盘事件监听
	$("body").keydown(function(e){
		if(isStart){
			if(!keyStatus){
			keyStatus=true;
			}else{
				return false;
			}
		}
		if(e.keyCode==116||e.keyCode==8){
			return true;
		}
		//按F1弹出帮助窗口
		if(e.keyCode==112){
			e.preventDefault();
			showReadme();
			return false;
		}
		//ESC案件呼出隐藏菜单
		if(e.keyCode==27){
			if($(".help:hidden").size()>0)
				$(".help").show();
			else
				$(".help").hide();
			
			return false;
		}
        
		if(e.keyCode==37){
			$(".prev").click();
			return false;
		}
		if(e.keyCode==39){
			$(".next").click();
			return false;
		}
		//当程序出于暂停状态
		if(pause){
			//以下按键有效 数字键 0-9 和 小键盘 0-9
			return true;
		}
		//存在未中奖用户切程序出于未开始运行状态执行开始方法
		if((e.keyCode==32||e.keyCode==65)&&$("div.item:not(.ignore)").size()!=0&&!isStart){
			isStart=!isStart;
			startApp();
			return false;
		}
		
		if(e.keyCode==32||e.keyCode==65){
			
			//当所有抽奖号全部抽取完毕则销毁跑马和音效循环
			if($("div.item:not(.ignore)").size()==0){
				clearInterval(tx);
				clearInterval(runtx);
				runingmic.puase();
				
				alert("抽奖已经全部结束。");
				return false;
			}
			//更新运行状态
			isRun=!isRun;
			//如果项目出于运行状态
			if(!isRun){
				//取得当前选中号码
				var it = $(".item.active");

				var xuehao = it.find(".xuehao").text();
				var xingming = it.find(".xingming").text();

				console.log("得出结果：");
				console.log(xingming);
				console.log(xuehao);


				//停止跑马灯
				runingmic.pause();
				//Math.floor($(".sequence li").size()/ts)
				
				//播放中奖音效
				pausemic.currentTime = 0;
				pausemic.play();
				$(".nowstu").css("display","none");

				//中奖号处理
                var r = '<p style="text-align:center"><strong style="color:green">&nbsp; 三   &nbsp;&nbsp;  等  &nbsp;&nbsp;   奖</strong></br><strong>姓名: '+xingming+'</strong></p>';
                var o = '<p style="text-align:center"><strong style="color:red">&nbsp; 一  &nbsp;&nbsp;   等   &nbsp;&nbsp;  奖</strong></br><strong>姓名: '+xingming+'</strong></p>';
                var t = '<p style="text-align:center"><strong style="color:blue">&nbsp; 二   &nbsp;&nbsp;  等 &nbsp;&nbsp;   奖</strong></br><strong>姓名: '+xingming+'</strong></p>';
                var a = '<p style="text-align:center"><em >&nbsp; 没   &nbsp;&nbsp;  有 &nbsp;&nbsp;   奖  &nbsp;&nbsp;  啦  !</em></br><strong>姓名: '+xingming+'</strong></p>';
                var b;

				if(v>3){
                    $('.ss ol').append('<li style="color:green;font-size:0.9em" data-number='+xuehao+'><strong>'+xuehao +' 姓名 :'+ xingming+'</strong><em>三等奖</em></li>');
				}else if(v>1){
                    $('.ss ol').append('<li style="color:blue;font-size:0.9em" data-number='+xuehao+'><strong>'+xuehao +' 姓名 :'+ xingming+'</strong><em>二等奖</em></li>');
                    b = r;
                    r = t;
				}else if(v>0) {
                    $('.ss ol').append('<li style="color:red;font-size:0.9em" data-number='+xuehao+'><strong>'+xuehao +' 姓名 :'+ xingming+'</strong><em>一等奖</em></li>');
                    b = r;
                    r = o;
				}else {
                    $('.ss ol').append('<li style="font-size:0.9em" data-number='+xuehao+'><strong>'+xuehao +' 姓名 :'+ xingming+'</strong></br><em>运气差极了</em></li>');
                    b = r;
                    r = a;
				}
				v--;
				console.log("剩余人数为："+v);
                // if(r==n){
                //     r='<h3>'+r+'！</h3>';
                // }else{
                //     r='<h2>恭喜您，抽得'+r+'！</h2>';
                // }
                var dd = dialog({
                        title: '抽奖结果',
                        content: r,
                        okValue: '确定'
                    });
                dd.show();
                localStorage.setItem("sequence",$(".ss").html()); 
				$(".item.active").addClass("ignore");
				$(".item.active").pulsate({
					color: zzs,        //#98ff98
					repeat: 5
				});
				r=b;
				b=null;
			}else{
				$(".active").removeClass("active");
				runingmic.play();
			}
		}
		
		e.preventDefault();
	});
	
	//打开高级设置窗口	 
	$("a.config").click(function(){
		pause=true;
		runingmic.pause();
		var d = dialog({
			title: '抽奖参数设定',
		    content: $(".model"),
		    okValue: '确定',
		    ok: function () {
		    	if($("#reset:checked").val()&&confirm("点击确定将清空抽奖结果。")){
		    		localStorage.removeItem("sequence");
		    	}
		    	if($("#personCount").val()){
		    		localStorage.setItem("itemCount",$("#personCount").val());
		    	}
		   		if($("#itemk").val()){
		   			localStorage.setItem("itemk",$("#itemk").val());
		    	}
		   		if($("#itemg").val()){
		    		localStorage.setItem("itemg",$("#itemg").val());
		    	}
		    	localStorage.setItem("title",$("#title").val());
		    	localStorage.setItem("ms",$("input[name=ms]:checked").val());
		    	localStorage.setItem("pf",$("input[name=pf]:checked").val());
		    	
		    	window.location.reload();
		    },onclose: function () {
		        pause=false;
		    }
			});
			d.show();
		 });
	
	//清除错误中奖号
	$("body").on("click",".item.ignore",function(){
		var inputItemCount = prompt("请输入点击的号码来进行删除中奖号码（例如“12”）。");
		if(inputItemCount == $(this).text()){
			$("li[data-number="+$(this).text()+"]").remove();
			$(this).removeClass("ignore");
			localStorage.setItem("sequence",$(".ss").html());	
			
                }else{
		}
		
	});
};
//程序开始入口
function startApp(){
	//开始播放跑马灯音效
	runingmic.play();
 	//产生随机数临时变量
	var rand =0
	//存储上一次随机数的临时变量
	var prenum;
	tx=setInterval(function(){
	    if(isRun){
	    	while(true){
				rand=Math.floor(Math.random() * ( $("div.item:not(.ignore)").size()));
			 	if(rand ==0 || rand!=prenum){break;}
			}
			prenum=rand;
			$(".item.active").removeClass("active");

			var notdiv = $("div.item:not(.ignore):not(.active)").eq(rand);

			notdiv.addClass("active");
			var xuehao = notdiv.find(".xuehao").text();
			var xingming = notdiv.find(".xingming").text();
			$("body").scrollTop(notdiv.offset().top);

			$(".nowstu").css("display","block");
			$(".nowstuh3").html(xingming);
			$(".nowstup").html(xuehao);

			//aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
		}
	},pl);
	runtx = setInterval(function(){runingmic.currentTime = 0;},7000);
}
function showReadme(){
	var d = dialog({
		    title: '帮助信息',
		    content: $(".readme") ,
		    width:'400px',
		    okValue: '关闭',
			ok:function(){
		    },
		    onclose: function () {
		        pause=false;
		    }
	}).show();
}

var dynamicLoading = {
    css: function(path){
		if(!path || path.length === 0){
			throw new Error('argument "path" is required !');
		}
		var head = document.getElementsByTagName('head')[0];
        var link = document.createElement('link');
        link.href = path;
        link.rel = 'stylesheet';
        link.type = 'text/css';
        head.appendChild(link);
    },
    js: function(path){
		if(!path || path.length === 0){
			throw new Error('argument "path" is required !');
		}
		var head = document.getElementsByTagName('head')[0];
        var script = document.createElement('script');
        script.src = path;
        script.type = 'text/javascript';
        head.appendChild(script);
    }
}


